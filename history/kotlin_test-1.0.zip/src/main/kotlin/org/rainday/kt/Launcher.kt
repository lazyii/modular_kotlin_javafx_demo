package org.rainday.kt

import javafx.application.Application
import org.rainday.avaj.mvvm.StarterApplication


/**
 * @author wyd
 * @date 2021-07-09 10:26:04
 * @version 1.0 edit by wyd at 2021-07-09 10:26:04
 */



fun main(args: Array<String>) {
    Application.launch(StarterApplication::class.java, *args)
}

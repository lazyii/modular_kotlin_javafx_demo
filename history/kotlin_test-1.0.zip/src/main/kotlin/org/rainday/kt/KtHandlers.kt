package org.rainday.kt


/**
 * @author wyd
 * @date 2021-07-08 10:36:03
 * @version 1.0 edit by wyd at 2021-07-08 10:36:03
 */
/*object KtHandlers {
    public val buttonHandler11 = EventHandler<ActionEvent> {
        GlobalScope.launch {

            println(this)
            println("launch")

        }
    }
}*/


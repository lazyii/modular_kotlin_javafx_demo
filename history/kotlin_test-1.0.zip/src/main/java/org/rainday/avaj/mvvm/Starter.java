package org.rainday.avaj.mvvm;

import javafx.application.Application;

/**
 * @author admin
 * @version 1.0 edit by admin at 2021-07-04 18:15:36
 * @date 2021-07-04 18:15:36
 */
public class Starter {
    public static void main(String...args){
        Application.launch(StarterApplication.class, args);
    }
}
